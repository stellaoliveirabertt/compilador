﻿namespace $safeprojectname$
{
    public class InfIdentificador
    {
        public string tipo;
    }
}
